require('babel-core/register')

module.exports = require('./nightwatch.json')
